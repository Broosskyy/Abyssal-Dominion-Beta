#!/usr/bin/env python3
"""Lossless geometry / mobile texture optimization of the nine ORIGINAL Meshy ships.

Accepts the user-supplied Meshy GLB files and ONLY recompresses embedded PBR
textures. Does not modify positions, normals, indices, UVs or triangle count.
This deliberately avoids mesh decimation, which previously fractured ship hulls.
"""
from pathlib import Path
from PIL import Image
from io import BytesIO
import hashlib
import json
import struct
import sys

INPUT = Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/meshy_originals')
OUTPUT = Path(sys.argv[2]) if len(sys.argv)>2 else Path('/mnt/data/Abyssal_GLBS_fixed/models')
OUTPUT.mkdir(parents=True,exist_ok=True)
NAMES = {
 'old_harbor_trader': 'Meshy_AI_Old_Harbor_Trader_1105202956_texture.glb',
 'merchant_brig_3002': 'Meshy_AI_Weathered_Merchant_Br_1105203002_texture.glb',
 'merchant_brig_2921': 'Meshy_AI_Weathered_Merchant_Br_1105202921_texture.glb',
 'merchant_brig_2912': 'Meshy_AI_Weathered_Merchant_Br_1105202912_texture.glb',
 'weathered_voyager': 'Meshy_AI_Weathered_Voyager_1105202906_texture.glb',
 'weathered_junk': 'Meshy_AI_Weathered_Junk_Ship_1105202938_texture.glb',
 'emerald_voyager': 'Meshy_AI_Emerald_Voyager_1105202952_texture.glb',
 'midnight_mariner': 'Meshy_AI_Midnight_Mariner_1105202902_texture.glb',
 'crimson_tide_galley': 'Meshy_AI_Crimson_Tide_Galley_1105202947_texture.glb',
}

def unpack(raw):
 if raw[:4]!=b'glTF' or struct.unpack_from('<I',raw,4)[0]!=2:raise ValueError('GLB v2 required')
 if struct.unpack_from('<I',raw,8)[0]!=len(raw):raise ValueError('length mismatch')
 jlen,jtyp=struct.unpack_from('<II',raw,12)
 if jtyp!=0x4e4f534a:raise ValueError('JSON chunk missing')
 j=json.loads(raw[20:20+jlen]); pos=20+jlen
 blen,btyp=struct.unpack_from('<II',raw,pos)
 if btyp!=0x004e4942: raise ValueError('BIN chunk missing')
 blob=raw[pos+8:pos+8+blen]
 return j,blob

def align4(data,fill=b'\0'):
 return data+fill*((-len(data))%4)

def build(j,blob):
 j['buffers'][0]['byteLength']=len(blob)
 doc=align4(json.dumps(j,separators=(',',':'),ensure_ascii=False).encode(),b' ')
 blob=align4(blob)
 raw=b'glTF'+struct.pack('<II',2,12+8+len(doc)+8+len(blob))
 return raw+struct.pack('<II',len(doc),0x4e4f534a)+doc+struct.pack('<II',len(blob),0x004e4942)+blob

def signature(j,blob):
 """Byte-for-byte digest of all non-image bufferViews and triangle counts."""
 image_ids={x['bufferView'] for x in j.get('images',[]) if 'bufferView' in x}
 hashed=hashlib.sha256()
 for i,v in enumerate(j['bufferViews']):
  if i in image_ids:continue
  p=v.get('byteOffset',0);n=v['byteLength']
  hashed.update(blob[p:p+n])
 tris=sum(j['accessors'][p['indices']]['count']//3 for m in j['meshes'] for p in m['primitives'] if 'indices' in p)
 return hashed.hexdigest(),tris

def optimize(src,dest):
 raw=src.read_bytes();j,blob=unpack(raw)
 before_hash,tris=signature(j,blob)
 if tris<28000:raise ValueError(f'Geometry already damaged in {src.name}: {tris} faces')
 images={im['bufferView']: im for im in j.get('images',[]) if 'bufferView' in im}
 rewritten=bytearray(); reports=[]
 for index,view in enumerate(j.get('bufferViews',[])):
  p=view.get('byteOffset',0);data=blob[p:p+view['byteLength']]
  if index in images:
   im=images[index];name=im.get('name','').lower()
   picture=Image.open(BytesIO(data)).convert('RGB')
   if 'normal' in name:target=768;fmt='PNG';mode='normal'
   elif 'roughness' in name or 'metallic' in name:target=512;fmt='PNG';mode='pbr'
   else:target=1024;fmt='JPEG';mode='albedo'
   if max(picture.size)>target:picture.thumbnail((target,target),Image.Resampling.LANCZOS)
   out=BytesIO()
   if fmt=='PNG':picture.save(out,format=fmt,optimize=True,compress_level=7)
   else:picture.save(out,format=fmt,quality=94,subsampling=0,optimize=True)
   data=out.getvalue()
   im['mimeType']='image/jpeg' if fmt=='JPEG' else 'image/png'
   reports.append({'slot':mode,'size':list(picture.size),'bytes':len(data)})
  rewritten.extend(bytes((-len(rewritten))%4))
  view['byteOffset']=len(rewritten);view['byteLength']=len(data)
  rewritten.extend(data)
 new=build(j,rewritten)
 check_j,check_blob=unpack(new)
 after_hash,after_tris=signature(check_j,check_blob)
 assert before_hash==after_hash and tris==after_tris,(src,tris,after_tris)
 dest.write_bytes(new)
 return {'file':dest.name,'original':src.name,'triangles':tris,'geometry_sha256':before_hash,'bytes_before':len(raw),'bytes_after':len(new),'textures':reports}

manifest={'schema':2,'geometry_preserved':True,'mesh_decimation':False,'models':[]}
for key,filename in NAMES.items():
 src=INPUT/filename
 if not src.is_file():raise FileNotFoundError(src)
 manifest['models'].append(optimize(src,OUTPUT/(key+'.glb')))
(OUTPUT.parent/'geometry_validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'count':len(manifest['models']), 'source_mb':round(sum(x['bytes_before'] for x in manifest['models'])/1e6,2),'output_mb':round(sum(x['bytes_after'] for x in manifest['models'])/1e6,2),'triangles':[x['triangles'] for x in manifest['models']]},indent=2))
